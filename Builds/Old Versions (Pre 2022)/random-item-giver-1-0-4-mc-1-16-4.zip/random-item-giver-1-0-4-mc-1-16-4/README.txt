README.txt

This data pack was created by Louis9. It's a basic data pack that gives you a random item every 5 seconds.
You can also change the time items are given. You can find information how to do that in the Main.mcfunction 
file in the randomitemgiver folder.

It is possible to use this datapack in Multiplayer, but everybody gets the same items.

Are you allowed to make videos of this datapack?
-> Yes, you are allowed to. If you send me the link, i take a look at it and may be linking it on the data pack
   page.
   
Are you allowed to change the code and/or reupload it?
-> You are not allowed to reupload it in the same version as my data pack but you are allowed to upload modified 
   versions of it, like updates to snapshots or new minecraft versions. 
   
I will continue updating this data pack to new stable minecraft versions. Also, if you find a bug, it would be nice
if you report it. That's all ^^ hope you enjoy my data pack. The idea for this data pack, i actually got from 
Phoenix SC. Here is his video: https://www.youtube.com/watch?v=L4kFPn0BBYY So i decided to make a similar data pack, 
but just for newer minecraft versions, because his datapack is only 1.15.2.